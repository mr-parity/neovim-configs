return {
  'nvim-lualine/lualine.nvim',
  dependencies = { 'nvim-tree/nvim-web-devicons' },
 
  opts = {
    options = {
      theme = 'auto', -- Connects lualine to your catppuccin theme
    },
  },
}

